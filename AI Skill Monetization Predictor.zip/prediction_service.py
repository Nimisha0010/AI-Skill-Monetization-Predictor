# backend/services/prediction_service.py
import joblib
import numpy as np
import os
from services.demand_service import get_demand_score, get_competition_score

MODELS_DIR = os.path.join(os.path.dirname(__file__), "../models")

# Load models once at startup
salary_model = joblib.load(os.path.join(MODELS_DIR, "salary_model.pkl"))
freelance_model = joblib.load(os.path.join(MODELS_DIR, "freelance_model.pkl"))
growth_model = joblib.load(os.path.join(MODELS_DIR, "growth_model.pkl"))

LOCATION_MULTIPLIER = {
    "usa": 1.0, "uk": 0.85, "india": 0.35,
    "germany": 0.90, "australia": 0.92,
}

def encode_skill(skill: str) -> float:
    """Simple hash-based encoding — replace with LabelEncoder in production."""
    return float(hash(skill.lower()) % 1000) / 1000.0

def run_prediction(skill: str, experience: float, location: str, hours_per_week: float, db=None) -> dict:
    skill_enc = encode_skill(skill)
    loc_key = location.lower().strip()
    loc_mult = LOCATION_MULTIPLIER.get(loc_key, 0.5)

    demand_score = get_demand_score(skill)
    competition_score = get_competition_score(skill)

    features = np.array([[skill_enc, experience, loc_mult, demand_score]])

    salary_pred = float(salary_model.predict(features)[0])
    freelance_pred = float(freelance_model.predict(features)[0]) * hours_per_week * 4
    growth_pred = float(growth_model.predict(features)[0])

    monetization_score = (
        0.4 * min(salary_pred / 2_000_000, 1.0) * 100
        + 0.3 * min(freelance_pred / 100_000, 1.0) * 100
        + 0.2 * (growth_pred / 100)
        - 0.1 * (competition_score / 100)
    )
    monetization_score = max(0, min(100, monetization_score))

    return {
        "salary_prediction": round(salary_pred, 2),
        "freelance_income": round(freelance_pred, 2),
        "demand_score": round(demand_score, 2),
        "competition_score": round(competition_score, 2),
        "growth_prediction": round(growth_pred, 2),
        "monetization_score": round(monetization_score, 2),
    }

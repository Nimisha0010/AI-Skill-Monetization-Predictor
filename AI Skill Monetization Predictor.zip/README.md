# AI Skill Monetization Predictor

Predict salary potential, freelance income, demand, and growth trends for any skill using ML.

## Quick Start

### 1. Clone & configure
```bash
git clone <repo-url>
cd skill-monetization-predictor
cp .env.example .env   # Fill in DATABASE_URL etc.
```

### 2. Run with Docker
```bash
cd deployment
docker-compose up --build
```
- Frontend: http://localhost:3000  
- API docs: http://localhost:8000/docs

### 3. Run ML training (first time)
```bash
cd data_pipeline
python job_scraper.py       # Scrape job data
python data_cleaning.py     # Clean raw data
python dataset_builder.py   # Build training set

cd ../ml_engine
python train_salary_model.py
python train_freelance_model.py
python growth_forecast_model.py
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/predict/` | Predict monetization for one skill |
| POST | `/compare/` | Compare 2–5 skills side by side |
| POST | `/recommendations/` | Get personalized skill recommendations |

## Monetization Score Formula
```
Score = 0.4 × Salary Potential
      + 0.3 × Freelance Potential
      + 0.2 × Demand Growth
      − 0.1 × Competition Risk
(normalized 0–100)
```

## Tech Stack
- **Frontend**: Next.js, Tailwind CSS, Recharts
- **Backend**: FastAPI, SQLAlchemy, Redis
- **ML**: XGBoost, Prophet, Scikit-learn
- **Database**: PostgreSQL
- **Deployment**: Docker, Vercel (frontend), AWS/Render (backend)
